import {TeaPage} from "../../teas/TeaPage.js";
import {TeaCardComponent} from "../../components/tea-card/TeaCardsComponents.js";

export class MainPage {
    constructor(parent) {
        this.parent = parent;
    }

    getData() {
        return [
            {
                id: 1,
                src: "https://i.postimg.cc/xjkMtrVM/Black-tea.jpg",
                name: "Чёрный чай",
                text: "Ассам"
            },
            {
                id: 2,
                src: "https://i.postimg.cc/fRsdzJtf/Green-tea.jpg",
                name: "Зелёный чай",
                text: "Лунцзин"
            },
            {
                id: 3,
                src: "https://i.postimg.cc/6382jZgt/White-tea.jpg",
                name: "Белый чай",
                text: "Бай Му Дань"
            },
        ]
    }

    get page() {
        return document.getElementById('main-page')
    }

    getHTML() {
        return (
            `
            <div id="main-page" class="d-flex flex-wrap"><div/>
            `
        )
    }

    clickCard(e) {
        const cardId = e.target.dataset.id

        const TPage = new TeaPage(this.parent, cardId)
        TPage.render(cardId)
    }

    render() {
        this.parent.innerHTML = ''
        const html = this.getHTML()
        this.parent.insertAdjacentHTML('beforeend', html)

        const data = this.getData()
        data.forEach((item) => {
            const TeaCard = new TeaCardComponent(this.page)
            TeaCard.render(item, this.clickCard.bind(this))
        })
    }
}
