import {TeaComponent} from "../components/teas/TeaComponent.js";
import {BackButtonComponent} from "../components/back-button/BackButtonComponent.js";
import {MainPage} from "../pages/main/MainPage.js";

export class TeaPage {
    constructor(parent, id) {
        this.parent = parent
        this.id = id
    }

    getData(cardId) {
        if (cardId == 1) {
            return {
                id: 1,
                src: "https://i.postimg.cc/xjkMtrVM/Black-tea.jpg",
                name: "Чёрный чай",
                text: "Ассам",
                description: "Сорт чёрного крупнолистового чая, выращиваемого на северо-востоке Индии, в долине реки Брахмапутры, между Шиллонгом и Восточными Гималаями."
            }
        }
        if (cardId == 2) {
            return {
                id: 2,
                src: "https://i.postimg.cc/fRsdzJtf/Green-tea.jpg",
                name: "Зелёный чай",
                text: "Лунцзин",
                description: "Разновидность зелёного чая из Ханчжоу, провинция Чжэцзян, Китай. Изготовляется, как правило, вручную, вследствие чего цена на этот сорт выше по сравнению с большинством сортов. Отмечен почётным титулом Знаменитый чай Китая."
            }
        }
        if (cardId == 3) {
            return {
                id: 3,
                src: "https://i.postimg.cc/6382jZgt/White-tea.jpg",
                name: "Белый чай",
                text: "Бай Му Дань",
                description: "Это сорт белого чая, для производства которого используют чайную почку и два верхних листика одного размера чайного дерева Да бай ча."
            }
        }
    }



    get page() {
        return document.getElementById('tea-page')
    }

    clickBack() {
        const mainPage = new MainPage(this.parent)
        mainPage.render()
    }

    getHTML() {
        return (
            `
                <div id="tea-page">
                </div>
            `
        )
    }

    render(cardId) {
        this.parent.innerHTML = ''
        const html = this.getHTML()
        this.parent.insertAdjacentHTML('beforeend', html)

        const backButton = new BackButtonComponent(this.page)
        backButton.render(this.clickBack.bind(this))

        const data = this.getData(cardId)
        const tea = new TeaComponent(this.page)
        tea.render(data)
    }
}