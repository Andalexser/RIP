from stocks.models import Tea
from rest_framework import serializers


class TeaSerializer(serializers.ModelSerializer):
    class Meta:
        # Модель, которую мы сериализуем
        model = Tea
        # Поля, которые мы сериализуем
        fields = ["ID", "NAME", "VARIETY", "DESCRIPTION"]