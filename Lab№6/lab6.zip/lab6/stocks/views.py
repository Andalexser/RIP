from rest_framework import viewsets
from stocks.serializers import TeaSerializer
from stocks.models import Tea


class TeaViewSet(viewsets.ModelViewSet):
    """
    API endpoint, который позволяет просматривать и редактировать акции компаний
    """
    # queryset всех пользователей для фильтрации по дате последнего изменения
    queryset = Tea.objects.all().order_by('ID')
    serializer_class = TeaSerializer  # Сериализатор для модели