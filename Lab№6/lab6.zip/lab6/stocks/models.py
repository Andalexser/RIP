from django.db import models

class Tea(models.Model):
    ID = models.BigAutoField(db_column='ID', primary_key=True)
    NAME = models.CharField(db_column='NAME', max_length=30)
    VARIETY = models.CharField(db_column='VARIETY', max_length=30, blank=True, null=True)
    DESCRIPTION = models.CharField(db_column='DESCRIPTION', max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'Teas'
