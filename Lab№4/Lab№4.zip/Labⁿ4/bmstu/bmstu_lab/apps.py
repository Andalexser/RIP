from django.apps import AppConfig


class BmstuLabConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bmstu_lab'
