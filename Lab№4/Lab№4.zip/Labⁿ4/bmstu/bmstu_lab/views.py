from django.shortcuts import render
from django.http import HttpResponse
from datetime import date

def GetOrders(request):
    return render(request, 'orders.html', {'data' : {
        'current_date': date.today(),
        'orders': [
            {'title': 'Чёрный чай', 'id': 1, 'des': '1'},
            {'title': 'Зелёный чай', 'id': 2, 'des': '1'},
            {'title': 'Белый чай', 'id': 3, 'des': '1'},
        ]
    }})

def GetOrder(request, id):
    return render(request, 'order.html', {'data' : {
        'current_date': date.today(),
        'id': id,
    }})
