import pyodbc

connectionString = ("Driver={SQL Server Native Client 11.0};"
                    "Server=LAPTOP-NVBTH5SF;"
                    "Database=Hot drinks;"
                    "Trusted_Connection=yes;")    

request1 = "INSERT INTO dbo.Teas (NAME, VARIETY, DESCRIPTION) VALUES ('Белый чай', 'шоу Мэй', 'Этот белый чай в основном выращивается в китайских провинциях Фуцзянь или Гуанси. Его изготавливают из почки и верхнего листа, остатков 4-й категории от Байхао Иньчжэнь.');"

request2 = "SELECT * FROM dbo.Teas"

connection = pyodbc.connect(connectionString, autocommit=True)
dbCursor = connection.cursor()
#dbCursor.execute(request1)
dbCursor.execute(request2)
for row in dbCursor:
    print(f"{row.ID} {row.NAME} {row.VARIETY} {row.DESCRIPTION}")
connection.commit()
dbCursor.close()
connection.close()

