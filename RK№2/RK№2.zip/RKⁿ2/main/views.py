from django.shortcuts import render
from .models import *
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django import forms
from datetime import datetime


def index(request):
    return render(request, 'main/index.html')


def report(request):
    drivers = Student.objects.all()
    params = {'students': students, 'date': datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
    return render(request, 'main/report.html', params)


def driver_list(request):
    drivers = Student.objects.all().values()
    params = {'entity': 'Student', 'objects': students}
    return render(request, 'main/list.html', params)


def group_list(request):
    parks = Group.objects.all().values()
    params = {'entity': 'Group', 'objects': parks}
    return render(request, 'main/list.html', params)


class GroupCreate(CreateView):
    model = Group
    fields = ['name']
    success_url = '/group'
    template_name = 'main/group_form.html'


class GroupUpdate(UpdateView):
    model = Group
    fields = ['name']
    gr_url_kwarg = 'id'
    success_url = '/group'
    template_name = 'main/group_form.html'


class GroupDelete(DeleteView):
    model = Group
    pk_url_kwarg = 'id'
    success_url = '/group'
    template_name = 'main/group_delete_form.html'


class StudentCreate(CreateView):
    model = Student
    fields = ['name', 'averper', 'group_id']
    success_url = '/student'
    template_name = 'main/student_form.html'

    def get_context_data(self, **kwargs):
        context = super(StudentCreate, self).get_context_data(**kwargs)
        context['form'].fields['droup_id'] = forms.ModelChoiceField(queryset=Group.objects.all(),
                                                                    empty_label=None, label='Группа')
        return context


class StudentUpdate(UpdateView):
    model = Student
    fields = ['name', 'averper', 'group_id']
    pk_url_kwarg = 'id'
    success_url = '/student'
    template_name = 'main/student_form.html'

    def get_context_data(self, **kwargs):
        context = super(StudentUpdate, self).get_context_data(**kwargs)
        context['form'].fields['group_id'] = forms.ModelChoiceField(queryset=Group.objects.all(),
                                                                   empty_label=None, label='Группа')
        return context


class StudentDelete(DeleteView):
    model = Student
    pk_url_kwarg = 'id'
    success_url = '/student'
    template_name = 'main/student_delete_form.html'
