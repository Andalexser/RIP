from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('group', views.group_list),
    path('group/create', views.GroupCreate.as_view()),
    path('group/<int:id>/update', views.GroupUpdate.as_view(), name='group_update'),
    path('group/<int:id>/delete', views.GroupDelete.as_view(), name='group_delete'),
    path('student', views.driver_list),
    path('student/create', views.StudentCreate.as_view()),
    path('student/<int:id>/update', views.StudentUpdate.as_view(), name='student_update'),
    path('student/<int:id>/delete', views.StudentDelete.as_view(), name='student_delete'),
    path('report', views.report)
]
