from django.db import models


class Student(models.Model):
    id = models.BigAutoField(db_column='ID', primary_key=True)
    name = models.CharField(db_column='NAME', max_length=30)
    averper = models.CharField(db_column='AVERPER', max_length=30, blank=True, null=True)
    group_id = models.CharField(db_column='GROUP_ID', max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'Students'


class Group(models.Model):
    id = models.BigAutoField(db_column='ID', primary_key=True) 
    name = models.CharField(db_column='NAME', max_length=30)  

    class Meta:
        db_table = 'Groups'


class StudentGroup(models.Model):
    id = models.BigAutoField(db_column='ID', primary_key=True)  
    Student_id = models.ForeignKey('Tea', models.DO_NOTHING, db_column='Teas_ID')  
    Group_id = models.ForeignKey('Coffee', models.DO_NOTHING, db_column='Coffees_ID')  

    class Meta:
        db_table = 'StudentGroups'




