from django.db import models
# 1

class Tea(models.Model):
    ID = models.BigAutoField(db_column='ID', primary_key=True)
    NAME = models.CharField(db_column='NAME', max_length=30)
    VARIETY = models.CharField(db_column='VARIETY', max_length=30, blank=True, null=True)
    DESCRIPTION = models.CharField(db_column='DESCRIPTION', max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'Teas'


class Coffee(models.Model):
    ID = models.BigAutoField(db_column='ID', primary_key=True) 
    NAME = models.CharField(db_column='NAME', max_length=30)  
    VARIETY = models.CharField(db_column='VARIETY', max_length=30, blank=True, null=True)  
    DESCRIPTION = models.CharField(db_column='DESCRIPTION', max_length=255, blank=True, null=True)  

    class Meta:
        db_table = 'Coffees'


class Cocoa(models.Model):
    ID = models.BigAutoField(db_column='ID', primary_key=True)  
    NAME = models.CharField(db_column='NAME', max_length=30)  
    VARIETY = models.CharField(db_column='VARIETY', max_length=30, blank=True, null=True)  
    DESCRIPTION = models.CharField(db_column='DESCRIPTION', max_length=255, blank=True, null=True)  

    class Meta:
        db_table = 'Cocoas'


class SetHotDrinks(models.Model):
    ID = models.BigAutoField(db_column='ID', primary_key=True)  
    Teas_ID = models.ForeignKey('Tea', models.DO_NOTHING, db_column='Teas_ID')  
    Coffees_ID = models.ForeignKey('Coffee', models.DO_NOTHING, db_column='Coffees_ID')  
    Cocoas_ID = models.ForeignKey('Cocoa', models.DO_NOTHING, db_column='Cocoas_ID')  

    class Meta:
        db_table = 'Set hot drinks'



